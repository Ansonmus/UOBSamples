﻿namespace UOL.UnifeedXIEWebBrowserWinForms.UnifeedObjects
{
	public enum Languagecode
	{
		EN = 0,

		NL = 1,

		FR = 2,

		DE = 3
	}
}
