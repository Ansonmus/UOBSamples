﻿namespace UOL.UnifeedXIEWebBrowserWinForms.UnifeedObjects
{
	public enum Filtercode
	{
		Brand = 0,

		Model = 1,

		Version = 2,

		ProductClass = 3,

		ModellingClass = 4
	}
}
